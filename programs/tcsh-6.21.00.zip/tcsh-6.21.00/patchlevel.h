/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 21
#define PATCHLEVEL 00
#define DATE "2019-05-08"

#endif /* _h_patchlevel */
